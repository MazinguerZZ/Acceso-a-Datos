/**
 * 
 */
/**
 * 
 */
module AgendaGUI {
	requires java.desktop;
}