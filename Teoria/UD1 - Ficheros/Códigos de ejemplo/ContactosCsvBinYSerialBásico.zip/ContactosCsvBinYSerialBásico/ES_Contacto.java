package modelo;


import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class ES_Contacto {
	
	@SuppressWarnings("unchecked")
	public static List<Contacto> contactosFromSerialFile(String fileName) {
		try ( ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(fileName))) {
			return (List<Contacto>)entrada.readObject();
		} catch (FileNotFoundException e) {
			return null;
		} catch (IOException e) {
			return null;
		} catch (ClassNotFoundException e) {
			return null;
		}
		
	} // contactosFromSerialFile
	
	public static boolean contactosToSerialFile (String fileName, List<Contacto> contactos) {
		try (
			ObjectOutputStream salida = new ObjectOutputStream(
					new FileOutputStream(fileName))
			)
		{
			salida.writeObject(contactos);
			return true;
		} catch (FileNotFoundException e) {
			return false;
		} catch (IOException e) {
			System.err.println(e.getClass());
			return false;
		}
	} // contactosToSerialFile
	
	
	public static List<Contacto> contactosFromBinaryFile(String fileName) {
		List<Contacto> resultado = new ArrayList<Contacto>();
		
		try (
				DataInputStream entrada = new DataInputStream( new FileInputStream(fileName))
			)
		{
			while (true) { //entrada.available()>0 ) {
				String nombre = entrada.readUTF();
				String teléfono = entrada.readUTF();
				resultado.add(new Contacto(nombre,teléfono));
			}
			//return resultado;
			
		} catch (FileNotFoundException e) {
			return null;
		} catch (EOFException e) {
			//System.err.println(e.getClass());
			return resultado;
		} catch (IOException e) {
			return resultado;
		}
	} // contactosFromBinaryFile
	
	
	public static boolean contactosToBinaryFile (String fileName, List<Contacto> contactos) {
		try (
				DataOutputStream salida = new DataOutputStream( new FileOutputStream(fileName))
			)
		{
			for (Contacto contacto : contactos) {
				salida.writeUTF(contacto.getNombre());
				salida.writeUTF(contacto.getTeléfono());
			}
			return true;
		} catch (FileNotFoundException e) {
			return false;
		} catch (IOException e) {
			return false;
		}
		
	} // contactosToBinaryFile
	
	
	public static List<Contacto> contactosFromCSV(String fileName) {
		List<Contacto> resultado = new ArrayList<Contacto>();
		
		try (BufferedReader entrada = new BufferedReader(new FileReader(fileName))){
			
			String línea;
			while ( (línea=entrada.readLine())!=null) {
				Contacto c = Contacto.contactoFromCSV(línea);
				if (c!=null) resultado.add(c);
				else System.err.println("Línea errónea, no contiene contacto: " + línea);
				/*
				String[] data = línea.split(",");
				if (data.length!=2) {
					System.err.println("Línea errónea, no contiene contacto: " + línea);
				}
				else {
					resultado.add(new Contacto(data[0],data[1]));
				}
				*/
			}
		}
		catch (FileNotFoundException e) {
			System.err.println("No se encuentra fichero " + fileName);
			return null;
		}
		catch (IOException e) {
			System.err.println("Algo fue mal abriendo o leyendo el fichero " + fileName);
		}
		
		return resultado;
	}
	
	public static boolean contactosToCSV(String fileName, List<Contacto> contactos) {
		try (PrintWriter salida = new PrintWriter(fileName)){
			for (Contacto c : contactos) {
				salida.println(c.getNombre() + "," + c.getTeléfono());
			}
		}
		catch (IOException e) {
			System.err.println("Problema abriendo o leyendo fichero " + fileName);
			return false;
		}
		
		return true;
	} // contactosToCSV
	
} // class
