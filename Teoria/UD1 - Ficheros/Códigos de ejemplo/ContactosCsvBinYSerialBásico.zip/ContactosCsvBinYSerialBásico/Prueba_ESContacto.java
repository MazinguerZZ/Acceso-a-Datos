package control;
import modelo.ES_Contacto;
import java.util.List;
import modelo.Contacto;

public class Prueba_ESContacto {
	public static final String RUTA_FICHERO_ENTRADA = "contactos.csv";
	public static final String RUTA_FICHERO_SALIDA = "contactos2.csv";
	public static final String RUTA_FICHERO_BINARIO = "contactos.data";
	public static final String RUTA_FICHERO_SERIAL = "contactos.ser";
	
	public static void main(String[] args) {
		/*
		try (FileReader f = new FileReader(RUTA_FICHERO_ENTRADA)){
			System.out.println("Codificación: " + f.getEncoding());
		} catch (IOException e) {
			System.out.println("No pude procesar " + RUTA_FICHERO_ENTRADA);
		}
		*/
		
		List<Contacto> agenda;
		
		agenda = ES_Contacto.contactosFromSerialFile(RUTA_FICHERO_SERIAL);
		if (agenda==null) {
			agenda = ES_Contacto.contactosFromBinaryFile(RUTA_FICHERO_BINARIO);
		}
		if (agenda==null) {
			ES_Contacto.contactosFromCSV(RUTA_FICHERO_ENTRADA);
		}
		if (agenda==null) {
			System.out.println("No ha sido posible leer CSV, BIN ni SERIAL");
			return;
		}
		if (agenda!=null) {
			agenda.forEach(System.out::println);
		}
		// Volcado a CSV
		if (ES_Contacto.contactosToCSV(RUTA_FICHERO_SALIDA, agenda)) {
			System.out.println("Datos volcados correctamente a archivo " + RUTA_FICHERO_SALIDA);
		}
		else {
			System.out.println("Problemas volcando datos a archivo "+ RUTA_FICHERO_SALIDA);
		}
		// Volcado a fichero binario:
		if (ES_Contacto.contactosToBinaryFile(RUTA_FICHERO_BINARIO, agenda)) {
			System.out.println("Datos volcados correctamente a archivo binario");
		}
		else {
			System.out.println("Problemas volcando datos a binario ");
		}
		// Volcado a fichero serial:
		if (ES_Contacto.contactosToSerialFile(RUTA_FICHERO_SERIAL, agenda)) {
			System.out.println("Datos volcados correctamente a archivo serial");
		}
		else {
			System.out.println("Problemas volcando datos a serial ");
		}
	}

}
