package control;

import java.io.File;
import java.io.IOException;

import modelo.Alumno;
import modelo.Clase;
import modelo.ES_Alumnos;

public class PruebaClase {

	public static final String csvFileName = "alumnos.csv";
	public static final String ficheroSalidaTxt = "alumnos.txt";
	public static final String ficheroBinario = "alumnos.bin";
	public static final String ficheroSerial = "alumnos.dat";
	
	public static void main(String[] args) {
		Clase daw1 = null;
		File archivoBinario = new File(ficheroBinario);
		File archivoSerial = new File(ficheroSerial);
		File archivoCsv = new File(csvFileName);
		
		try {
			// Intento leer los datos del disco en el primer formato que encuentre
			daw1 = ES_Alumnos.leerClaseDeCsv(archivoCsv);
			if (daw1==null || daw1.size()==0) {
				daw1 = ES_Alumnos.leerClaseDeBin(archivoBinario);
			}
			if (daw1==null || daw1.size()==0) {
				daw1 = ES_Alumnos.leerClaseDeSerial(archivoSerial);
			}
			if (daw1==null) daw1 = new Clase();
			
			System.out.println("Alumnos leídos: " + daw1);
			// Permite añadir alumnos por teclado
			Alumno a;
			while ( (a=ES_Alumnos.leeAlumnoDeTeclado())!=null) {
				daw1.insertar(a);
			}
			System.out.println("Ahora hay todos estos: " + daw1);
			// Guardo los datos en disco en los tres formatos:
			ES_Alumnos.imprimeClaseATxt(new File(ficheroSalidaTxt), daw1);
			ES_Alumnos.guardaClaseSerial(archivoSerial,daw1);
			ES_Alumnos.guardaClaseBin(archivoBinario,daw1);
			ES_Alumnos.guardaClaseEnCsv(archivoCsv,daw1);
			
		} catch (IOException e) {
			System.err.println("Problemas con el disco");
			System.err.println(e.getMessage());
		}
	} // main
	
} // class PruebaClase