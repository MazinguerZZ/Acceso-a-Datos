package control;

import modelo.Agenda;
import modelo.AgendaSaver;
import modelo.Contacto;
import java.io.*;
import java.util.Scanner;

public class PruebaSerialización {

	public static void main(String[] args) {
		String fileName = "contactos.bin";
		Agenda agenda;
		AgendaSaver guardaObjetos = new AgendaSaver();
		Scanner entrada = new Scanner(System.in);
		
		System.out.print("¿Primera ejecución (S/N)?");
		String respuesta = entrada.next();
		try {
			if (respuesta.toLowerCase().startsWith("s")) {
				agenda = new Agenda(2);
				agenda.addContacto(new Contacto("Pepe","65588994"));
				agenda.addContacto(new Contacto("Luis","44545999"));
				guardaObjetos.guarda(agenda,fileName);
				System.out.println("Agenda guardada");
			}
			else {
				agenda = guardaObjetos.recupera(fileName);
				System.out.println("Agenda leída");
			}
			System.out.println(agenda);
		
		}
		catch (IOException | ClassNotFoundException e) {
			System.err.println("Algo fue mal: " + e.getMessage());
		}
		
		
		
	} // class

}
