package modelo;

import java.io.Serializable;

public class Agenda implements Serializable {
	public static final int DEFAULT_SIZE = 100;
	
	private Contacto[] agenda;
	private int size;
	
	public Agenda(int maxSize) {
		agenda = new Contacto[maxSize];
		size = 0;
	}
	
	public Agenda() {
		this(DEFAULT_SIZE);
	}
	
	public boolean addContacto(Contacto c) {
		if (size >= agenda.length) return false;
		agenda[size++] = c;
		return true;
	}
	
	public Contacto getContacto(int pos) {
		if (pos<0 && pos>size) return null;
		return agenda[pos];
	}
	
	public int size() {
		return size;
	}
	
	public String toString() {
		StringBuilder stb = new StringBuilder("Agenda:\n");
		for (int pos=0; pos<size;pos++) {
			stb.append(agenda[pos] + "\n");
		}
		return stb.toString();
	}
	
} // class Agenda
