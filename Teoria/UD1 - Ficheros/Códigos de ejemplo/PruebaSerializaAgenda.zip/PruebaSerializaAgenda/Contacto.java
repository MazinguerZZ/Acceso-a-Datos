package modelo;

import java.io.Serializable;
import java.util.Date;

public class Contacto implements Serializable {
	private String nombre;
	private String telefono;
	private String email;
	private String direccion;
	private Date nacimiento;
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public Date getNacimiento() {
		return nacimiento;
	}
	public void setNacimiento(Date nacimiento) {
		this.nacimiento = nacimiento;
	}
	public Contacto(String nombre, String telefono) {
		this(nombre,telefono,"","",new Date());
	}
	public Contacto(String nombre, String telefono, String email, String direccion, Date nacimiento) {
		super();
		this.nombre = nombre;
		this.telefono = telefono;
		this.email = email;
		this.direccion = direccion;
		this.nacimiento = nacimiento;
	}
	
	@Override
	public String toString() {
		return "Nombre: " + nombre
				+ ", Teléfono: " + telefono
				+ ", Email: " + email
				+ ", Direccion: " + direccion
				+ ", Nacimiento: " + nacimiento;
	}
	
} // class Contacto
