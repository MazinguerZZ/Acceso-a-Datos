package modelo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class AgendaSaver {
	public static final String DEFAULT_FILENAME="contactos.bin";
	/*
	private String fileName;
	
	public AgendaSaver(String fileName) {
		this.fileName = fileName;
	}
	
	public AgendaSaver() {
		this(DEFAULT_FILENAME);
	}
	*/
	
	public Agenda recupera(String fileName) throws ClassNotFoundException, IOException {
		FileInputStream file;
		ObjectInputStream input;
		file = new FileInputStream(fileName);
		input = new ObjectInputStream(file);
		Agenda agenda = (Agenda)input.readObject();
		input.close();
		file.close();
		return agenda;
	}
	
	public void guarda(Agenda a, String fileName) throws IOException {
		FileOutputStream file;
		ObjectOutputStream output;
		file = new FileOutputStream(fileName);
		output = new ObjectOutputStream(file);
		/*
		for (int pos=0; pos<a.size(); pos++) {
			Contacto c = a.getContacto(pos);
			output.writeObject(c);
		}
		*/
		output.writeObject(a);
		output.close();
		file.close();
	}
} // class
