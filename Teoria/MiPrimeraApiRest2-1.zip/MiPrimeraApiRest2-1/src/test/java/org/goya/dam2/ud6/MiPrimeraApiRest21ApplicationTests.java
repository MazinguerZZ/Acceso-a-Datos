package org.goya.dam2.ud6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiPrimeraApiRest21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
