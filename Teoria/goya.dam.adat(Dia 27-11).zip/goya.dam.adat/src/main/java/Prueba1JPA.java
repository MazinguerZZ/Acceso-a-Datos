import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Prueba1JPA {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("UnidadPersonas");
		EntityManager em = emf.createEntityManager();

		Persona yo = new Persona("Javier", 54);
		Persona tu = new Persona("Alumno Random", 19);
		
		yo.addEmail("yo@dominio.com");
		yo.addEmail("yo2@dominio.com");
		yo.addEmail("yo3@dominio.com");

		tu.addEmail("tu@dominio.com");
		tu.addEmail("tu2@dominio.com");


		//Email email = new Email("yo@midominio.com");
		//yo.addEmail(email);
		System.out.println(yo);
		
		try {
			em.getTransaction().begin();
			em.persist(yo);
			em.persist(tu);
			
			em.getTransaction().commit();
			System.out.println("Todo ha ido bien");
			System.out.println(yo);
		} catch (Exception e) {
			e.printStackTrace();
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			System.err.println("Ha sido un desastre");

		} finally {
			em.close();
			emf.close();
		}
	}
}