import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Persona {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Long id;
	
	@OneToMany(cascade = CascadeType.ALL ,mappedBy = "persona", fetch = FetchType.EAGER)
	Set<Email> emails = new HashSet<Email>();
	
	public Email addEmail(Email email) {
		emails.add(email);
		//email.setPersona(this);
		return email;
	}
	
	public boolean delEmail(Email email) {
		return emails.remove(email);
	}
	
	public Email addEmail(String emailStr) {
		Email email = new Email(emailStr);
		return this.addEmail(email);
		//email.setPersona(this);
	}
	
	/*public boolean delEmail(String emailStr) {
		return emails.remove(emailStr);
	}*/
	
	public Set<Email> getEmails() {
		return emails;
	}

	public void setEmails(Set<Email> emails) {
		this.emails = emails;
	}

	private String nombre;
	private int edad;

	public Persona() {
		super();
	}

	public Persona(String nombre, int edad) {
		super();
		setEdad(edad);
		setNombre(nombre);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	@Override
	public int hashCode() {
		return nombre.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		Persona nueva = (Persona) obj;
		return nueva.getNombre().equals(this.getNombre());
	}
	
	@Override
	public String toString() {
		/*
		String strEmails = "";
		for (Email email : emails) {
			strEmails += email + ",";
		}
		*/
		return "Persona [id=" + id + ", nombre=" + nombre + ", edad=" + edad + ", email: " + emails + "]";
	}
}