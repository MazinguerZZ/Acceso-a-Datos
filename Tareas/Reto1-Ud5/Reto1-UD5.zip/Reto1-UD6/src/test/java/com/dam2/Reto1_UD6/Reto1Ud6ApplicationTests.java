package com.dam2.Reto1_UD6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto1Ud6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
