package com.dam2.Reto1_UD5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reto1Ud5Application {

	public static void main(String[] args) {
		SpringApplication.run(Reto1Ud5Application.class, args);
	}

}
