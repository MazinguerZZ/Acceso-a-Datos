package com.dam2.Reto1_UD5;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface RepositorioConsumidor extends MongoRepository<Consumidor, String> {

  public Consumidor findByFirstName(String firstName);
  public List<Consumidor> findByLastName(String lastName);

}
