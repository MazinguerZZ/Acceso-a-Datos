/**
 * 
 */
/**
 * 
 */
open module Reto2_UD1_2 {
    
    requires java.xml;
    requires java.sql;
    requires xstream;
    requires gson;
    requires org.json;
    requires jettison;
	
    exports pojo;

}