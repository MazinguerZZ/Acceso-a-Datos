import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

/**
 * Entidad JPA que representa la tabla SCOTT (empleados).
 * 
 * - @Entity indica que la clase es persistente en la base de datos.
 * - No se usa @Table ni @Column, por lo que los nombres de tabla y columnas
 *   se generan automáticamente según los nombres de clase y atributos.
 */
@Entity
public class Scott {

    /** Clave primaria de la entidad */
    @Id
    private Long empno;

    /** Nombre del empleado */
    private String ename;

    /** Puesto de trabajo */
    private String job;

    /** Número de empleado del jefe */
    private int mgr;

    /** Salario */
    private int sal;

    /** Comisión */
    private int comm;

    /** Número de departamento al que pertenece */
    private int deptno;

    // ==================== Constructores ====================

    /** Constructor vacío obligatorio para JPA */
    public Scott() {
        super();
    }

    /**
     * Constructor completo para crear instancias rápidamente
     * @param empno Identificador del empleado
     * @param ename Nombre del empleado
     * @param job Puesto
     * @param mgr Jefe
     * @param sal Salario
     * @param comm Comisión
     * @param deptno Departamento
     */
    public Scott(long empno, String ename, String job, int mgr, int sal, int comm, int deptno) {
        super();
        this.empno = empno;
        this.ename = ename;
        this.job = job;
        this.mgr = mgr;
        this.sal = sal;
        this.comm = comm;
        this.deptno = deptno;
    }

    // ==================== Getters y Setters ====================

    public Long getEmpno() { return empno; }
    public void setEmpno(Long empno) { this.empno = empno; }

    public String getEname() { return ename; }
    public void setEname(String ename) { this.ename = ename; }

    public String getJob() { return job; }
    public void setJob(String job) { this.job = job; }

    public int getMgr() { return mgr; }
    public void setMgr(int mgr) { this.mgr = mgr; }

    public int getSal() { return sal; }
    public void setSal(int sal) { this.sal = sal; }

    public int getComm() { return comm; }
    public void setComm(int comm) { this.comm = comm; }

    public int getDeptno() { return deptno; }
    public void setDeptno(int deptno) { this.deptno = deptno; }

    // ==================== Métodos auxiliares ====================

    /**
     * Representación textual del objeto para depuración o impresión
     */
    @Override
    public String toString() {
        return "Scott [empno=" + empno + ", ename=" + ename + ", job=" + job + ", mgr=" + mgr +
               ", sal=" + sal + ", comm=" + comm + ", deptno=" + deptno + "]";
    }

    /**
     * hashCode basado en todos los atributos de la clase
     * útil si se usa en colecciones tipo Set o Map
     */
    @Override
    public int hashCode() {
        return Objects.hash(comm, deptno, empno, ename, job, mgr, sal);
    }

    /**
     * equals compara dos objetos Scott por todos sus atributos
     * útil para comprobar igualdad en tests o colecciones
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Scott other = (Scott) obj;
        return comm == other.comm && deptno == other.deptno && Objects.equals(empno, other.empno)
               && Objects.equals(ename, other.ename) && Objects.equals(job, other.job)
               && mgr == other.mgr && sal == other.sal;
    }
}
