import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Clase para probar un CRUD completo sobre la entidad Scott.
 * 
 * Acciones:
 * 1. Lectura de todos los registros (Read)
 * 2. Actualización de un registro (Update)
 * 3. Eliminación de registros (Delete)
 * 4. Creación de registros (Create)
 */
public class tablasScott1_2 {

    public static void main(String[] args) {

        // ==================== Crear EntityManager ====================
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("UnidadScott2");
        EntityManager em = emf.createEntityManager();

        try {
            // ==================== READ ====================
            em.getTransaction().begin();
            System.out.println("LECTURA: ");

            List<Scott> scott = em.createQuery("SELECT a FROM Scott a", Scott.class).getResultList();

            for (Scott a : scott) {
                System.out.println("EMPNO: " + a.getEmpno() + ", ENAME: " + a.getEname() + ", JOB: " + a.getJob() +
                                   ", MGR: " + a.getMgr() + ", SAL: " + a.getSal() + ", COMM: " + a.getComm() +
                                   ", DEPTNO: " + a.getDeptno());
            }

            em.getTransaction().commit();

            // ==================== UPDATE ====================
            System.out.println("\nUPDATE: ");
            em.getTransaction().begin();

            Scott scottUpdate = em.find(Scott.class, 7001L); // Buscar por PK
            if (scottUpdate != null) {
                scottUpdate.setSal(15000); // Modificar salario
                em.merge(scottUpdate);     // Guardar cambios
            }

            em.getTransaction().commit();

            // Mostrar resultados después del UPDATE
            for (Scott a : scott) {
                System.out.println("EMPNO: " + a.getEmpno() + ", ENAME: " + a.getEname() + ", JOB: " + a.getJob() +
                                   ", MGR: " + a.getMgr() + ", SAL: " + a.getSal() + ", COMM: " + a.getComm() +
                                   ", DEPTNO: " + a.getDeptno());
            }

            // ==================== DELETE ====================
            System.out.println("\nDELETE: ");
            em.getTransaction().begin();

            // Eliminar todos los empleados leídos anteriormente
            for (Scott scottDelete : scott) {
                // Asegurarse de que el objeto está gestionado
                Scott toRemove = em.find(Scott.class, scottDelete.getEmpno());
                if (toRemove != null) {
                    em.remove(toRemove);
                }
            }
            System.out.println("Se han eliminado todos los campos");

            em.getTransaction().commit();

            // ==================== CREATE ====================
            System.out.println("\nCREATE: ");
            em.getTransaction().begin();

            // Ejemplo: crear nuevos empleados si quieres
            Scott nuevoEmpleado = new Scott(7004, "Laura", "ANALYST", 7604, 1400, 900, 20);
            em.persist(nuevoEmpleado);

            em.getTransaction().commit();

            // Leer todos para verificar creación
            List<Scott> scottFinal = em.createQuery("SELECT a FROM Scott a", Scott.class).getResultList();
            for (Scott a : scottFinal) {
                System.out.println("EMPNO: " + a.getEmpno() + ", ENAME: " + a.getEname() + ", JOB: " + a.getJob() +
                                   ", MGR: " + a.getMgr() + ", SAL: " + a.getSal() + ", COMM: " + a.getComm() +
                                   ", DEPTNO: " + a.getDeptno());
            }

        } catch (Exception e) {
            System.out.println("Error " + e);
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
        } finally {
            // Cerrar recursos
            em.close();
            emf.close();
        }
    }
}
