package goya.dam2.adat.ud6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenUd6Application {

	public static void main(String[] args) {
		SpringApplication.run(ExamenUd6Application.class, args);
	}

}
