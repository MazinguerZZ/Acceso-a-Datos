package JPA_Ejer2_3_4;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class tablasScott2_2 {
	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("UnidadScott2");
		EntityManager em = emf.createEntityManager();

		try {
			em.getTransaction().begin();
			System.out.println("LECTURA: ");

			List<Scott2> scott = em.createQuery("SELECT a FROM Scott2 a", Scott2.class).getResultList();

			for (Scott2 a : scott) {
				System.out.println("EMPNO: " + a.getEmpno() + ", ENAME: " + a.getEname() + ", JOB: " + a.getJob() + ", MGR: " + a.getMgr()
				+ ", SAL: " + a.getSal() + ", COMM: " + a.getComm() + ", DEPTNO: " + a.getDeptno());
			}

			em.getTransaction().commit();
			
			
			System.out.println("\nUPDATE: ");
			
			em.getTransaction().begin();
			Scott2 scottUpdate = em.find(Scott2.class, 7001L);
			
			if (scottUpdate != null) {
				scottUpdate.setSal(15000);
				em.merge(scottUpdate);
				System.out.println("Salario actualizado para empno 7001");
			} else {
				System.out.println("No se encontro empleado con empno 7001");
			}
			em.getTransaction().commit();
			
			em.getTransaction().begin();
			List<Scott2> scottActualizado = em.createQuery("SELECT a FROM Scott2 a", Scott2.class).getResultList();
			System.out.println("\nDespues del UPDATE:");
			for (Scott2 a : scottActualizado) {
				System.out.println("EMPNO: " + a.getEmpno() + ", ENAME: " + a.getEname() + ", SAL: " + a.getSal());
			}
			em.getTransaction().commit();
			
			
			System.out.println("\nDELETE: ");
			
            em.getTransaction().begin();
            List<Scott2> paraEliminar = em.createQuery("SELECT a FROM Scott2 a", Scott2.class).getResultList();
            
            for (Scott2 scottDelete : paraEliminar) {
                em.remove(scottDelete);
            }
            em.getTransaction().commit();
            System.out.println("Empleados eliminados");
			
			
			
			System.out.println("\nCreate: ");
			
            em.getTransaction().begin();
            Scott2 nuevo1 = new Scott2(9001L, "Luis", "PROGRAMADOR", 7839, 2500, 300, 10);
            Scott2 nuevo2 = new Scott2(9002L, "Marta", "ANALISTA", 7839, 2800, 400, 20);
            
            em.persist(nuevo1);
            em.persist(nuevo2);
            em.getTransaction().commit();
            System.out.println("Nuevos empleados insertados");
			
			em.getTransaction().begin();
			List<Scott2> finalList = em.createQuery("SELECT a FROM Scott2 a", Scott2.class).getResultList();
			System.out.println("\nLISTA FINAL:");
			for (Scott2 a : finalList) {
				System.out.println("EMPNO: " + a.getEmpno() + ", ENAME: " + a.getEname() + ", JOB: " + a.getJob());
			}
			em.getTransaction().commit();
			
		} catch (Exception e) {
			e.printStackTrace();
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
		} finally {
			em.close();
			emf.close();
		}
	}
}