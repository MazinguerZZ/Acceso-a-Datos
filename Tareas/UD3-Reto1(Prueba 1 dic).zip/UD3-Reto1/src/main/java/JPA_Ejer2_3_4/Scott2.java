package JPA_Ejer2_3_4;

import java.util.Objects;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Column;

@Entity
@Table(name = "Scott2")
public class Scott2 {

	@Id
	@Column(name = "EMPNO")
	private Long empno;
	
	@Column(name = "ENAME")
	private String ename;
	
	@Column(name = "JOB")
	private String job;
	
	@Column(name = "MGR")
	private int mgr;
	
	@Column(name = "SAL")
	private int sal;
	
	@Column(name = "COMM")
	private int comm;
	
	@Column(name = "DEPTNO")
	private int deptno;

	// @ManyToOne
	// @JoinColumn(name = "DEPTNO")
	// private Departamento departamento;
	
	// @ManyToMany
	// private List<Proyecto> proyectos;

	
	public Scott2() {
		super();
	}


	public Scott2(long i, String ename, String job, int mgr, int sal, int comm, int deptno) {
		super();
		this.empno = i;
		this.ename = ename;
		this.job = job;
		this.mgr = mgr;
		this.sal = sal;
		this.comm = comm;
		this.deptno = deptno;
	}

	public Long getEmpno() {
		return empno;
	}


	public void setEmpno(Long empno) {
		this.empno = empno;
	}


	public String getEname() {
		return ename;
	}


	public void setEname(String ename) {
		this.ename = ename;
	}


	public String getJob() {
		return job;
	}


	public void setJob(String job) {
		this.job = job;
	}


	public int getMgr() {
		return mgr;
	}


	public void setMgr(int mgr) {
		this.mgr = mgr;
	}


	public int getSal() {
		return sal;
	}


	public void setSal(int sal) {
		this.sal = sal;
	}


	public int getComm() {
		return comm;
	}


	public void setComm(int comm) {
		this.comm = comm;
	}


	public int getDeptno() {
		return deptno;
	}


	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}


	@Override
	public String toString() {
		return "scott [empno=" + empno + ", ename=" + ename + ", job=" + job + ", mgr=" + mgr + 
				", sal=" + sal + ", comm=" + comm + ", deptno=" + deptno + "]";
	}


	@Override
	public int hashCode() {
		return Objects.hash(comm, deptno, empno, ename, job, mgr, sal);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Scott2 other = (Scott2) obj;
		return comm == other.comm && deptno == other.deptno && empno == other.empno
				&& Objects.equals(ename, other.ename) && Objects.equals(job, other.job) && mgr == other.mgr
				&& sal == other.sal;
	}
}
